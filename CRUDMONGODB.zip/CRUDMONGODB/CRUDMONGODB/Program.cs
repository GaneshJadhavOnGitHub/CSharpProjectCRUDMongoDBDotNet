#region Namespace
using System;
using System.Windows.Forms;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

#endregion

#pragma warning disable CS1587 // XML comment is not placed on a valid language element
/// <summary>
/// CRUD Functionality with MONGODB and Dot net framework <br/>
/// C - Create , R - Read , U - Update , D - Delete
/// Author :- Ganesh Kamalakar Jadhav.
/// Date :- June 03, 2022
/// </summary>
namespace CRUDMONGODB
#pragma warning restore CS1587 // XML comment is not placed on a valid language element
{
    /// <summary>
    /// Static class containing static Main method.
    /// </summary>
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Application.SetHighDpiMode(HighDpiMode.SystemAware);
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Run an instance of Form1.
            Form1 mainForm = new Form1();
            Application.Run(mainForm);
        }
    }
}
