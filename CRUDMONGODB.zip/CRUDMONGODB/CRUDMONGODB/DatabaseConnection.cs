﻿#region Namespace
//using System;
//using System.Collections.Generic;
//using System.Text;
#endregion

#pragma warning disable CS1587 // XML comment is not placed on a valid language element
/// <summary>
/// CRUD Functionality with MONGODB and Dot net framework<br/>
/// C - Create , R - Read , U - Update , D - Delete
/// Author :- Ganesh Kamalakar Jadhav.
/// Date :- June 03, 2022
/// </summary>
namespace CRUDMONGODB
#pragma warning restore CS1587 // XML comment is not placed on a valid language element
{

    
    /// <summary>
    /// Static class containing Connection String to the database.
    /// </summary>
    public static class DatabaseConnection
    {
        #region Class Variables
        /// <summary>
        /// Static string storing connection string used to connect to the database.
        /// </summary>

        //App.config file is not used, So line below is commented.
        //public static string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MongoDBConnection"].ToString();
        //As MongoDB server is running on local machine at port number 27017 (default port) , we are using ip address as 127.0.0.1 
        public static string ConnectionString = "mongodb://127.0.0.1:27017"; 
        
        //Instead of using ip address as 127.0.0.1 we ca use 'localhost', Therefore below string also works.
        //public static string ConnectionString = "mongodb://localhost:27017";

        #endregion

    }

}
