﻿#region
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Diagnostics;
//using System.Text;
//using System.Data;
//using System.Data.SqlClient;
#endregion

#pragma warning disable CS1587 // XML comment is not placed on a valid language element
/// <summary>
/// CRUD Functionality with MONGODB and Dot net framework <br/>
/// C - Create , R - Read , U - Update , D - Delete
/// Author :- Ganesh Kamalakar Jadhav.
/// Date :- June 03, 2022
/// </summary>
namespace CRUDMONGODB
#pragma warning restore CS1587 // XML comment is not placed on a valid language element
{
    /// <summary>
    /// Class containing database operations.
    /// </summary>
    public class DatabaseOperation
    {
        #region Class Methods

        /// <summary>
        /// Connects to the MongoDB Server and Returns specified collection from specified database. 
        /// </summary>
        /// <returns>Object of type IMongoCollection&lt;BsonDocument&gt;. <br/>
        /// Each item in this collection (IMongoCollection) is of type BsonDocument.
        /// </returns>
        public static IMongoCollection<BsonDocument> GetDocument()
        {
            IMongoCollection<BsonDocument> Movies = null;
            try
            {
                MongoClient mongoClient = new MongoClient(DatabaseConnection.ConnectionString);
                IMongoDatabase database = mongoClient.GetDatabase("BoxOffice"); //BoxOffice is the name of our database.
                //Movies is the name of our Collection (table) in the BoxOffice database.
                Movies = database.GetCollection<BsonDocument>("Movies");
            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception From GetDocument ";
                string exceptionInGetDocument = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionInGetDocument;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionInGetDocument;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }

            return Movies;
        }

        /// <summary>
        /// Get title of the Movie from MovieId (MovieID)
        /// </summary>
        /// <param name="MovieId">MovieID of the selected document.</param>
        /// <returns>Title of the movie</returns>
        public string GetTitleFromMovieID(int MovieId)
        {
            string title = "";
            try
            {
                IMongoCollection<BsonDocument> Movies = GetDocument();
                var listOfBsonDocuments = Movies.Find(new BsonDocument()).ToList();
                BsonElement[] fieldsArray; //Array to store fields from each Document in the Collection
                foreach (BsonDocument doc in listOfBsonDocuments)
                {
                    //Console.WriteLine(doc.ToString());
                    //IEnumerable<BsonElement> Field = doc.Elements;
                    fieldsArray = doc.Elements.ToArray();
                    if (Convert.ToInt32(fieldsArray[1].Value) == MovieId) //Index of MovieID is 1.
                        title = fieldsArray[2].Value.ToString(); //Index of Title is 2.
                }
                //Debug.WriteLine("Title of the Movie is :- {0}", title, null);

            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception From exceptionInGetTitleFromMovieID ";
                string exceptionInGetTitleFromMovieID = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionInGetTitleFromMovieID;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionInGetTitleFromMovieID;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }


            return title;

        }

        /// <summary>
        /// Gets the Maximum value of the MovieID Field from the Movies Collection.<br/>
        /// MovieID field should be Auto-Incremented Field. <br/>
        /// But MongoDB does not provide auto-increment functionality at the moment. <br/>
        /// Here, we are reading Maximum value of the MovieID Field from the Collection. <br/>
        /// Thus (Maximum value + 1) will be added as MovieID while adding new document in the Movies Collection. 
        /// </summary>
        /// <param name="listOfBsonDocuments">A list containing BsonDocuments from 'Movies' Collection.</param>
        /// <returns>An integer representing maximum value of the MovieID Field from the Movies Collection.</returns>
        public int GetMaximumMovieID(List<BsonDocument> listOfBsonDocuments)
        {
            int MAX = 0;
           try 
             {
                BsonElement[] fieldsArray; //Array to store fields from each Document in the Collection
                foreach (BsonDocument doc in listOfBsonDocuments)
                {
                    //Console.WriteLine(doc.ToString());
                    //IEnumerable<BsonElement> Field = doc.Elements;
                    fieldsArray = doc.Elements.ToArray();
                    int MovieId = Convert.ToInt32(fieldsArray[1].Value); //Index of MovieID is 1.
                    if (MovieId > MAX)
                    {
                        MAX = MovieId;
                    }

                }
                //Console.WriteLine(MAX);
                //Debug.WriteLine("Maximum Value of the MovieID is :- {0} ", MAX);

            }
            catch (Exception ex)
            {
                string messageToWrite = "Exception From GetMaximumMovieID ";
                string exceptionInGetMaximumMovieID = ex.Message;
                Type exType = ex.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionInGetMaximumMovieID;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionInGetMaximumMovieID;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }

            return MAX;
        }

        /// <summary>
        /// Inserts a document (record) into the Movies Collection (table).
        /// </summary>
        /// <param name="Movies">Collection to which document is to be added.</param>
        /// <param name="movieId">ID of the Movie</param>
        /// <param name="title">Title of the Movie</param>
        /// <param name="productionHouse">Name of the Production House</param>
        /// <param name="year">Year of release</param>
        /// <param name="budget">Budget of the movie in the Crores (₹)</param>
        /// <param name="collection">Collection of the movie in the Crores (₹)</param>
        /// <param name="verdict">Verdict</param>
        /// <returns>Number of documents (records) inserted.</returns>

        public int InsertIntoMovies(IMongoCollection<BsonDocument> Movies, int movieId, string title, string productionHouse, int year, decimal budget, decimal collection, string verdict)
        {
            int docsInserted = 0;
            try
            {
              BsonDocument movie = new BsonDocument
               {
                {"MovieID", movieId},
                {"Title", title},
                {"Production House", productionHouse},
                {"YearOfRelease", year},
                {"BudgetCrores", budget},
                {"CollectionCrores", collection},
                {"Verdict", verdict},
              };
                Movies.InsertOne(movie); 
                docsInserted = 1;

            }
            catch (Exception ex)
            {
                string messageToWrite = "Exception From InsesrtIntoMovies ";
                string exceptionWhileInsertingIntoMovies = ex.Message;
                Type exType = ex.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionWhileInsertingIntoMovies;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionWhileInsertingIntoMovies;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }
            return docsInserted;
        }

        /// <summary>
        /// Deletes a document (record) from the Movies collection.
        /// </summary>
        /// <param name="movieId">Movie Id of the record to be deleted.</param>
        /// <returns>Number of documents (records) deleted.</returns>
        public int Delete(int movieId)
        {
            int docsDeleted = 0;

            try
            {
                IMongoCollection<BsonDocument> Movies = DatabaseOperation.GetDocument();
                //Provide 'MovieID' of the Document to be deleted and identify that document using Filter.
                var filter = Builders<BsonDocument>.Filter.Eq("MovieID", movieId); 
                DeleteResult deleteResult = Movies.DeleteOne(filter);
                docsDeleted = Convert.ToInt32(deleteResult.DeletedCount);

            }
            catch (Exception ex)
            {
                string messageToWrite = "Exception From Delete ";
                string exceptionWhileDeleting = ex.Message;
                Type exType = ex.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionWhileDeleting;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionWhileDeleting;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }

            return docsDeleted;
        }

        /// <summary>
        /// Updates a document (record) in the Movies Collection (table).
        /// </summary>
        /// <param name="MovieId">Movie ID of the movie of which record to be updated.</param>
        /// <param name="title">New Title of the movie</param>
        /// <param name="productionHouse">New Production House</param>
        /// <param name="year">New year of release</param>
        /// <param name="budget">New budget in crores (₹)</param>
        /// <param name="collection">New collection in crores (₹) </param>
        /// <param name="verdict">New Verdict</param>
        /// <returns>Number of documents (records) updated.</returns>
        public int Update(int MovieId, string title, string productionHouse, int year, decimal budget, decimal collection,string verdict)
        {
            int docsUpdated = 0;

            try
            {
                IMongoCollection<BsonDocument> Movies = DatabaseOperation.GetDocument();

                //Provide 'MovieID' of the Document to be updated and identify that document using Filter.
                var filter = Builders<BsonDocument>.Filter.Eq("MovieID", MovieId);

                //Set new values of each field in the filtered document.
                var update = Builders<BsonDocument>.Update.Set("Title", title)
                                                          .Set("Production House", productionHouse)
                                                          .Set("YearOfRelease", year)
                                                          .Set("BudgetCrores", budget)
                                                          .Set("CollectionCrores", collection)
                                                          .Set("Verdict", verdict);

                UpdateResult updateResult = Movies.UpdateOne(filter, update);
                docsUpdated = Convert.ToInt32(updateResult.ModifiedCount);

            }
            catch (Exception ex)
            {
                string messageToWrite = "Exception From Update ";
                string exceptionWhileUpdating = ex.Message;
                Type exType = ex.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionWhileUpdating;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionWhileUpdating;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }
            
            return docsUpdated;
        }
       
        #endregion
    }

}
