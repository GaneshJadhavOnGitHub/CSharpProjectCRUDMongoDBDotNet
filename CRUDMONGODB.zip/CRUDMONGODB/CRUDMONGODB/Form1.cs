﻿#region Namespaces
using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Globalization;
using MongoDB.Driver;
using MongoDB.Bson;
using MongoDB.Driver.Linq;
using MongoDB.Bson.Serialization.Serializers;
using MongoDB.Bson.Serialization.Options;
using MongoDB.Bson.Serialization;
using System.Diagnostics;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Text;
//using System.Threading.Tasks;
#endregion

#pragma warning disable CS1587 // XML comment is not placed on a valid language element
/// <summary>
/// CRUD Functionality with MONGODB and Dot net framework <br/>
/// C - Create , R - Read , U - Update , D - Delete
/// Author :- Ganesh Kamalakar Jadhav.
/// Date :- June 03, 2022
/// </summary>
namespace CRUDMONGODB
#pragma warning restore CS1587 // XML comment is not placed on a valid language element
{
    /// <summary>
    /// Main Form of CRUD Functionality with MongoDB and Dot net framework <br/>
    /// C - Create , R - Read , U - Update , D - Delete
    /// Author :- Ganesh Kamalakar Jadhav.
    /// Date :- June 03, 2022
    /// </summary>
    public partial class Form1 : Form
    {
        #region Class Variable
        /// <summary>
        /// Static string to store name of the application. Declared as static because we are using it throughout the application.
        /// </summary>
        public static string applicationName = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
       
        /// <summary>
        /// Stores MovieID i.e. ID of the Movie.
        /// </summary>
        int MovieId;

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor of the Form Form1
        /// </summary>
        public Form1()
        {
            InitializeComponent();

            dateTimePicker1.Format = DateTimePickerFormat.Custom; //Custom DateTimePickerFormat, as we need to select year only.
            dateTimePicker1.CustomFormat = "yyyy"; //We need to select year only so display year only.
            dateTimePicker1.ShowUpDown = true;     //Show up-down keys to select year.
            
            //Disable right click. So user can't paste alphabets.
            ContextMenuStrip l_menu = new ContextMenuStrip();
            textBox3.ContextMenuStrip = l_menu;
            textBox4.ContextMenuStrip = l_menu;

            this.dataGridView1.MultiSelect = false; //User can't not select multiple cells/rows/columns of the datagridview at a time , So disable multiselect 

            //When user clicks on a Row Header in dataGridView1, we want the complete row to be selected.
            //So, we are handling this RowHeaderMouseClick event.
            //When this event occurs we are reading data from selected row into textboxes. 
            //This statement can also be put into InitializeComponent() Method. But I have written here.
            dataGridView1.RowHeaderMouseClick += new DataGridViewCellMouseEventHandler(dataGridView1_OnRowHeaderMouseClick);

        }

        #endregion

        #region Events

        /// <summary>
        /// Load event of Form1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            try
              {
                RegisterSerializerForDecimal(); //This method should be called only once.

                // Display data from the Movie Table inside the datagridview.
                PopulateDataGridView();


                //Disable Update and Delete Button.
                button2.Enabled = false;
                button3.Enabled = false;
            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception While Loading Form";
                string exceptionInForm1Load = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionInForm1Load;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionInForm1Load;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }

        }

        /// <summary>
        /// Handles the Key Press Event of textBox3.<br/>
        /// This textBox takes Budget amount of the Movie in Crores (₹). <br/>
        /// By handling this event we allow user to input 'digits and one decimal point' only. <br/> 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow digits only
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            /*
            else
            {
                MessageBox.Show("Only digits are allowed", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            */
            // Allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            /*
            else
            {
                MessageBox.Show("Only one decimal point is allowed", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            */

        }

        /// <summary>
        /// Handles the Key Press Event of textBox4.<br/>
        /// This textBox takes Collection amount of the Movie in Crores (₹). <br/>
        /// By handling this event we allow user to input 'digits and one decimal point' only. <br/>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Allow digits only
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            /*
            else
            {
                MessageBox.Show("Only digits are allowed", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            */
            // Allow one decimal point
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            /*
            else
            {
                MessageBox.Show("Only one decimal point is allowed", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            */

        }

        /// <summary>
        /// Handles KeyDown event of the textBox3 <br/>
        /// This textBox takes Budget amount of the Movie in Crores (₹). <br/>
        /// By handling this event we restrict ctrl+v key strokes , So user can't paste invalid characters.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            //Disable paste
            if (e.Control && e.KeyCode == Keys.V)
            {
                e.SuppressKeyPress = true;
            }
        }


        /// <summary>
        /// Handles KeyDown event of the textBox4 <br/>
        /// This textBox takes Collection amount of the Movie in Crores (₹). <br/>
        /// By handling this event we restrict ctrl+v key strokes , So user can't paste invalid characters.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            //Disable paste
            if (e.Control && e.KeyCode == Keys.V)
            {
                e.SuppressKeyPress = true;
            }
        }

        /// <summary>
        /// Handles the RowHeaderMouseClick event of the dataGridView1. <br/>
        /// Occurs when user clicks within the boundaries of the Row Header.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dataGridView1_OnRowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
           try
             {
                //Enable all TextBoxes and DateTimePicker.
                EnableInput();

                //Disable Insert button and enable Update and Delete Buttons
                button1.Enabled = false;
                button2.Enabled = true;
                button3.Enabled = true;

                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];  //Get the row when user clicks RowHeader in the datagridview.

                    //Get the data from all the cells of the selected row inside the TextBoxes and DataTimePicker.
                    //Here, we do not require Verdict column because We don't have any textbox to get it
                    //So, we do not read Verdict from the datagridview and it is a Calculated field/column. 
                    //i.e. It's value is calculated by the program and not entered by user.

                    //This 'MovieId' value will be used to identify document while update/delete operation.
                    //So, Read this value when this event occurs.
                    if (row.Cells["MovieID"].Value != DBNull.Value) //MovieID will be null if user selects a blank row.
                    {
                        MovieId = Convert.ToInt32(row.Cells["MovieID"].Value);
                    }

                    textBox1.Text = row.Cells["Title"].Value.ToString();
                    textBox2.Text = row.Cells["Production House"].Value.ToString();
                    textBox3.Text = row.Cells["Budget"].Value.ToString();
                    // Year will be displayed as an object inside the cell of the datagridview.
                    //Read that inside a string because we require a string as first argument to ParseExtract method.
                    string sYear = row.Cells["Year"].Value.ToString();
                    if (sYear != "") //If year is not blank, (we get an empty string  if user selects a blank row).
                    {
                        DateTime year = DateTime.ParseExact(sYear, "yyyy", new CultureInfo("en-US")); //Convert sYear to DateTime type.
                        dateTimePicker1.Value = year;
                    }

                    textBox4.Text = row.Cells["Collection"].Value.ToString();

                    //Verdict = row.Cells["Verdict"].Value.ToString(); //No input 
                }
              }
            catch (Exception exception)
            {
                string messageToWrite = "Exception In dataGridView1_OnRowHeaderMouseClick :- ";
                string exceptionIndataGridView1_OnRowHeaderMouseClick = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionIndataGridView1_OnRowHeaderMouseClick;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionIndataGridView1_OnRowHeaderMouseClick;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }


        }

            /// <summary>
            /// Read data from the row of the dataGridView1 in the textboxes, when user clicks a cell in the dataGridView1. 
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
           private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
           {
            //Enable all TextBoxes and DateTimePicker.
            EnableInput();

            //Disable Insert button and enable Update and Delete Buttons
            button1.Enabled = false; 
            button2.Enabled = true;
            button3.Enabled = true;

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];  //Get the row when user clicks a cell in the datagridview.

                //Get the data from all the cells of the selected row inside the TextBoxes and DataTimePicker.
                //Here, we do not require Verdict column because We don't have any textbox to get it
                //So, we do not read Verdict from the datagridview and it is a Calculated field/column. 
                //i.e. It's value is calculated by the program and not entered by user.

                //This 'MovieId' value will be used to identify document while update/delete operation.
                //So, Read this value when this event occurs.
                MovieId = Convert.ToInt32(row.Cells["MovieID"].Value); 
                textBox1.Text = row.Cells["Title"].Value.ToString();
                textBox2.Text = row.Cells["Production House"].Value.ToString();
                textBox3.Text = row.Cells["Budget"].Value.ToString();
                string sYear = row.Cells["Year"].Value.ToString();
                DateTime year = DateTime.ParseExact(sYear, "yyyy", new CultureInfo("en-US"));
                dateTimePicker1.Value = year;
                textBox4.Text = row.Cells["Collection"].Value.ToString();
                //Verdict = row.Cells["Verdict"].Value.ToString();

            }
        }

        /// <summary>
        /// Handles the DataBindingComplete event of the datagridview. <br/>
        /// Occurs when a data binding operaion has finished.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            //Hides the 'MovieID' column of the datagridview as we do not need to display this column to the user.
            this.dataGridView1.Columns["MovieID"].Visible = false; 
            
            this.dataGridView1.Columns["Production House"].Width = 150; //Sets the Width of 'Production House'
            this.dataGridView1.Columns["Title"].Width = 120;            //Sets the Width of 'Title'

        }

        

        /// <summary>
        /// Handles the click event of Button4 (Reset Button). <br/>
        /// Reset all the controls to appropriate state.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            ResetAll();
        }

        /// <summary>
        /// Handles the click event of Button1 (Insert Button). <br/>
        /// Perform Validation , Calculates Verdict and Insert record in the Movies table. <br/>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            try
              {
                DatabaseOperation databaseOperation = new DatabaseOperation();
                IMongoCollection<BsonDocument> Movies = DatabaseOperation.GetDocument();
                var listOfBsonDocuments = Movies.Find(new BsonDocument()).ToList();
                int MAX = databaseOperation.GetMaximumMovieID(listOfBsonDocuments);
                Debug.WriteLine("Maximum Value of the MovieID is :- {0} ", MAX);

                if ((textBox1.Text != "") && (textBox2.Text != "") && (textBox3.Text != "") && (textBox4.Text != "")) //Validate
                {
                    string Verdict = CalculateVerdict(textBox4.Text.TrimEnd(), textBox3.Text.TrimEnd()); //Calculate Verdict.

                    int docsInserted = 0;

                    decimal budgetCr = decimal.Parse(textBox3.Text);
                    decimal collectionCr = decimal.Parse(textBox4.Text);
                    //decimal budgetCr = StringToBsonCompatibleDecimal(textBox3.Text);
                    //decimal collectionCr = StringToBsonCompatibleDecimal(textBox4.Text);

                    //We are using MAX + 1 because MAX gives Maximum value of the MovieID Field.
                    //So, MAX+1 will be MovieID of the document to be added. 
                    docsInserted = databaseOperation.InsertIntoMovies(Movies, MAX + 1, textBox1.Text.TrimEnd(), textBox2.Text.TrimEnd(), dateTimePicker1.Value.Year, budgetCr, collectionCr, Verdict);

                    if (docsInserted == 1)
                    {
                        MessageBox.Show("Document added successfully!", applicationName + ": Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //PopulateDataGridView();
                        ResetAll();
                    }
                }

                else if ((textBox1.Text == "") || (textBox2.Text == "") || (textBox3.Text == "") || (textBox4.Text == ""))
                {
                    MessageBox.Show("Please fill all the fields.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception In button1_Click :- ";
                string exceptionInbutton1_Click = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionInbutton1_Click;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionInbutton1_Click;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }



        }

        /// <summary>
        /// Handles the click event of Button2 (Update Button). <br/>
        /// Calculate new Verdict and Update Document (Record) with the new values, as entered by the user. <br/>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            try
              {
                if (MovieId != 0) //If MovieId is non-zero, then only we can update document.
                {
                    string Verdict = CalculateVerdict(textBox4.Text.TrimEnd(), textBox3.Text.TrimEnd()); //Calculate Verdict.
                    int docsUpdated = 0;
                    decimal budgetCr = decimal.Parse(textBox3.Text);
                    decimal collectionCr = decimal.Parse(textBox4.Text);

                    DatabaseOperation databaseOperation = new DatabaseOperation();
                    string title = databaseOperation.GetTitleFromMovieID(MovieId);
                    //Console.Beep();
                    DialogResult dialogResult = MessageBox.Show("Do you really want to Update this document?\n" + " Movie : " + title, applicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (dialogResult == DialogResult.Yes)
                    {
                        docsUpdated = databaseOperation.Update(MovieId, textBox1.Text.TrimEnd(), textBox2.Text.TrimEnd(), dateTimePicker1.Value.Year, budgetCr, collectionCr, Verdict);
                    }
                    else if (dialogResult == DialogResult.No)
                    {
                        //clears textBoxes and populate dataGridView.
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        DateTime year = DateTime.ParseExact(DateTime.Now.Year.ToString(), "yyyy", new CultureInfo("en-US"));
                        dateTimePicker1.Value = year;
                        PopulateDataGridView();
                        //dataGridView1.Rows[0].Selected = false;
                        //dataGridView1.Refresh();
                    }
                    //Set MovieId to zero again after displying Dialog.
                    //We need to set it back to zero whether user updates document or not.
                    MovieId = 0;


                    if (docsUpdated > 0)
                    {
                        if (docsUpdated == 1)
                        {
                            MessageBox.Show(docsUpdated + " document updated SucessFully!", applicationName + " :Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        else if (docsUpdated > 1)
                        {
                            MessageBox.Show(docsUpdated + " documents updated SucessFully!", applicationName + " :Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        PopulateDataGridView(); //Populate datagridview again after updating record to show changes to the user.
                    }
                    else
                    {
                        MessageBox.Show("Can not Update. 0 documents affected.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }
                else
                {
                    MessageBox.Show("Please select a document (record) to be updated", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception In button2_Click :- ";
                string exceptionInbutton2_Click = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionInbutton2_Click;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionInbutton2_Click;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }


        }

        /// <summary>
        /// Handles the click event of Button3 (Delete Button). <br/>
        /// Deletes a particular document from the 'Movies' Collection.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            try
            { 
             if (MovieId != 0) //We can delete only of MovieId is non-zero.
            {
                int docsDeleted = 0;
                DatabaseOperation databaseOperation = new DatabaseOperation();
                //Console.Beep();
                DialogResult dialogResult = MessageBox.Show("Do you really want to Delete this document?\n" + " Movie Title: " + textBox1.Text, applicationName, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dialogResult == DialogResult.Yes)
                {
                    docsDeleted = databaseOperation.Delete(MovieId);

                }
                else if (dialogResult == DialogResult.No)
                {
                    //clears textBoxes and populate dataGridView.
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    DateTime year = DateTime.ParseExact(DateTime.Now.Year.ToString(), "yyyy", new CultureInfo("en-US"));
                    dateTimePicker1.Value = year;
                    PopulateDataGridView();
                    //dataGridView1.Rows[0].Selected = false;
                    //dataGridView1.Refresh();
                }
                //Set MovieId to zero again after displying Dialog.
                //We need to set it back to zero whether user updates document or not.
                MovieId = 0;
                if (docsDeleted > 0)
                {
                    if (docsDeleted == 1)
                    {

                        MessageBox.Show(docsDeleted + " document deleted SucessFully!", applicationName + " :Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    else if (docsDeleted > 1)
                    {
                        MessageBox.Show(docsDeleted + " documents deleted SucessFully!", applicationName + " :Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    PopulateDataGridView();   //Populate datagridview again after deleting record to show changes to the user.

                    //Reset all the TextBoxes and DateTimePicker.
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    DateTime year = DateTime.ParseExact(DateTime.Now.Year.ToString(), "yyyy", new CultureInfo("en-US"));
                    dateTimePicker1.Value = year;
                }
                else
                {
                    MessageBox.Show("Can not Delete. 0 documents affected.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
             else
            {
                MessageBox.Show("Please select a document (record) to be deleted", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception In button3_Click :- ";
                string exceptionInbutton3_Click = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionInbutton3_Click;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionInbutton3_Click;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }

        }

        #endregion

        #region Methods
        /// <summary>
        /// Disable Input controls to restrict user from entering data.
        /// </summary>
        private void DisableInput()
        {
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            dateTimePicker1.Enabled = false;
        }

        /// <summary>
        /// Enable input controls (TextBoxes and DateTimePicker) So that user can enter data.
        /// </summary>
        private void EnableInput()
        {
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            dateTimePicker1.Enabled = true;
        }

        /*
        /// Following are the 10 Verdict Categories. <br/>
        /// 1.DISASTER              (Loss > 40%) <br/>
        /// 2.FLOP                  (Loss > 20% and Loss <= 40%) <br/>
        /// 3.BELOW AVERAGE         (Loss <= 20% and Loss > 10%) <br/>
        /// 4.AVERAGE               (Collection is equal to budget with 10% Plus Minus +- i.e.  Loss < 10% OR Profit < 10%) <br/>
        /// 5.ABOVE AVERAGE         (Profit <= 20% and Profit > 10%)   <br/>
        /// 6.SEMI HIT              (Profit > 20% and Profit <= 40%)   <br/>
        /// 7.HIT                   (Profit > 40% and Profit <= 80%)   <br/>
        /// 8.SUPER HIT             (Profit > 80% and Profit <= 150%)  <br/>
        /// 9.BLOCKBUSTER           (Profit > 150% and Profit <= 300%) <br/>
        /// 10.ALL TIME BLOCKBUSTER (Profit > 300%)
         */

        /// <summary>
        /// Calculates Verdict based on Profit or Loss <br/>
        /// </summary>
        /// <param name="sCollection">Collection of the Movie in Crores (₹)</param>
        /// <param name="sBudget">Budget of the Movie in Crores (₹)</param>
        /// <returns>Verdict</returns>
        private string CalculateVerdict(string sCollection, string sBudget)
        {
            
            string verdict = "";
            try
            {
                float fBudget = float.Parse(sBudget);
                float fCollection = float.Parse(sCollection);
                if (fBudget == fCollection)
                {
                    verdict = "AVERAGE";
                }
                else if (fBudget > fCollection)
                {
                    var losspercentage = this.CalculatePercentage(fBudget, fCollection);
                    if (losspercentage > 40)
                    {
                        verdict = "DISASTER";
                    }
                    else if ((losspercentage > 20) && (losspercentage <= 40))
                    {
                        verdict = "FLOP";
                    }
                    else if ((losspercentage <= 20) && (losspercentage > 10))
                    {
                        verdict = "BELOW AVERAGE";
                    }
                    else if ((losspercentage > 0) && (losspercentage <= 10))
                    {
                        verdict = "AVERAGE";
                    }

                }

                else if (fCollection > fBudget)
                {
                    var profitpercentage = this.CalculatePercentage(fBudget, fCollection);
                    if ((profitpercentage > 0) && (profitpercentage <= 10))
                    {
                        verdict = "AVERAGE";
                    }
                    else if ((profitpercentage <= 20) && (profitpercentage > 10))
                    {
                        verdict = "ABOVE AVERAGE";
                    }
                    else if ((profitpercentage > 20) && (profitpercentage <= 40))
                    {
                        verdict = "SEMI HIT";
                    }
                    else if ((profitpercentage > 40) && (profitpercentage <= 80))
                    {
                        verdict = "HIT";
                    }
                    else if ((profitpercentage > 80) && (profitpercentage <= 150))
                    {
                        verdict = "SUPER HIT";
                    }
                    else if ((profitpercentage > 150) && (profitpercentage <= 300))
                    {
                        verdict = "BLOCKBUSTER";
                    }
                    else if (profitpercentage > 300)
                    {
                        verdict = "ALL TIME BLOCKBUSTER";
                    }
                }

            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception While Calculating Verdict :- ";
                string exceptionWhileCalculatingVerdict = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionWhileCalculatingVerdict;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionWhileCalculatingVerdict;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }

            return verdict;
        }

        /// <summary>
        /// Calculates loss or profit percentage based on budget and collection of the Movie. <br/>
        /// This percentage will be used while calculating Verdict.
        /// </summary>
        /// <param name="fBudget">Budget of the Movie in Crores (₹)</param>
        /// <param name="fCollection">Collection of the Movie in Crores (₹)</param>
        /// <returns>Profit OR Loss Percentage</returns>
        private float CalculatePercentage(float fBudget, float fCollection)
        {
            float percentage = 0;
            try
            {
                if (fBudget > fCollection) //Loss
                {
                    percentage = ((fBudget - fCollection) / fBudget) * 100;
                }
                else //Profit
                {
                    percentage = ((fCollection - fBudget) / fBudget) * 100;
                }
            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception While Calculating Percentage :- ";
                string exceptionWhileCalculatingPercentage = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionWhileCalculatingPercentage;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionWhileCalculatingPercentage;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }


            return percentage;
        }

        /// <summary>
        /// Populates dataGridView1 with the data from the Movies Table in the database.
        /// </summary>
        private async void PopulateDataGridView()
        {
            
            try
            {
                IMongoCollection<BsonDocument> Movies = DatabaseOperation.GetDocument();
                var documents = Movies.Find(new BsonDocument()).ToList();
                /*
                foreach (BsonDocument doc in documents)
                {
                    Console.WriteLine(doc.ToString());
                }
                */
                DataTable resultTable = new DataTable();
                var filter = new BsonDocument();
                //var count = 0;

                using (var cursor = await Movies.FindAsync(filter)) //Get a cursor to traverse the collection.
                {
                    while (await cursor.MoveNextAsync())
                    {
                        var document = cursor.Current; 
                        //Add columns to the DataTable (resultTable).
                        resultTable.Columns.Add("MovieID", typeof(Int32));
                        resultTable.Columns.Add("Title", typeof(string));
                        resultTable.Columns.Add("Production House", typeof(string));
                        resultTable.Columns.Add("YearOfRelease", typeof(string));
                        resultTable.Columns.Add("BudgetCrores", typeof(string));
                        resultTable.Columns.Add("CollectionCrores", typeof(string));
                        resultTable.Columns.Add("Verdict", typeof(string));

                        //Populate a row in the DataTable (resultTable).
                        //One item correponds to one row of the resultTable.
                        foreach (var item in document)
                        {
                            resultTable.Rows.Add(item["MovieID"], item["Title"], item["Production House"], item["YearOfRelease"], item["BudgetCrores"], item["CollectionCrores"], item["Verdict"]);
                        }
                        //count++; //Increment document counter.
                    }

                    this.dataGridView1.DataSource = resultTable;
                }

                //Currently columns in the resultTable have names same as names of the Fields in the Collection.
                //And we want custom column names we set them as below.
                resultTable.Columns[1].ColumnName = "Title";
                resultTable.Columns[2].ColumnName = "Production House";
                resultTable.Columns[3].ColumnName = "Year";
                resultTable.Columns[4].ColumnName = "Budget";
                resultTable.Columns[5].ColumnName = "Collection";
                resultTable.AcceptChanges();

                FormatDataGridView();



            }
            catch (Exception exceptionInPopulateDataGridView)
            {
                //MessageDialog messagebox = new MessageDialog("Display Data Error: " + ex);
                //await messagebox.ShowAsync();
                //throw exceptionInPopulateDataGridView;
                //MessageBox.Show("Exception in PopulateDataGridView : "+ exceptionInPopulateDataGridView.Message.ToString(), applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                MessageBox.Show("Exception in PopulateDataGridView : MongoDB server is not Running.", applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw exceptionInPopulateDataGridView;
            }
        }

        /// <summary>
        /// Format the dataGridView1 so that it will display data appropriately. <br/>
        /// Sets style of 'Verdict' column and Width of some columns. 
        /// </summary>
        private void FormatDataGridView()
        {
            this.dataGridView1.Columns["Verdict"].DefaultCellStyle.BackColor = Color.PaleTurquoise;
            this.dataGridView1.Columns["Verdict"].DefaultCellStyle.ForeColor = Color.DarkRed;
            //int yearWidth = this.dataGridView1.Columns[3].Width;
            this.dataGridView1.Columns[3].Width = 60;  //Set the width of 'Year' Column to 60; Default is 100.
            this.dataGridView1.Columns[4].Width = 80;  //Set the width of 'Budget' Column to 70; Default is 100.
            this.dataGridView1.Columns[5].Width = 90;  //Set the width of 'Collection' Column to 80; Default is 100.
            this.dataGridView1.Columns[6].Width = 180;  //Set the width of 'Verdict' Column to 180; Default is 100.
            this.dataGridView1.CurrentCell = this.dataGridView1.Rows[0].Cells[6];
            dataGridView1.Rows[0].Selected = false;
        }

        /// <summary>
        /// Resets all controls. <br/>
        /// Displays recent data in datagridview and refreshes it. <br/>
        /// Clears TextBoxes and DateTimePicker.
        /// </summary>
        private void ResetAll()
        {
            MovieId = 0;
            PopulateDataGridView();
            dataGridView1.Refresh();
            button1.Enabled = true;
            textBox1.Enabled = true;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            DateTime year = DateTime.ParseExact(DateTime.Now.Year.ToString(), "yyyy", new CultureInfo("en-US"));
            dateTimePicker1.Value = year;
            button2.Enabled = false;
            button3.Enabled = false;
        }

        /// <summary>
        /// Registers a Serializer which will be used to convert string into a BsonCompatible Decimal.
        /// </summary>
        private void RegisterSerializerForDecimal()
        {
            try 
            {
                DecimalSerializer decimalSerializer = new DecimalSerializer(BsonType.Decimal128, new RepresentationConverter(allowOverflow: false, allowTruncation: false));
                BsonSerializer.RegisterSerializer(decimalSerializer);
            }
            catch (Exception exception)
            {
                string messageToWrite = "Exception While Registering Serializer For Decimal :- ";
                string exceptionWhileRegisteringSerializerForDecimal = exception.Message;
                Type exType = exception.GetType();
                string exceptionType = exType.ToString();
                messageToWrite += exceptionType + " " + exceptionWhileRegisteringSerializerForDecimal;
                MessageBox.Show(messageToWrite, Form1.applicationName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                //messageToWrite += exceptionType + " " + exceptionWhileRegisteringSerializerForDecimal;
                //Logger.AppendMessageToStringBuilder(messageToWrite, 2);
            }
        }

        /* Commented out because first two statements of this method needs to be executed only once throughout the 
         * Lifetime of the Form ,otherwise program will throw error. New Method 'RegisterSerializerForDecimal()' 
         * is written and called at Form_Load().
        /// <summary>
        /// Converts string into BsonCompatible Decimal which is BsonType.Decimal128. <br/>
        /// <br/>
        /// Why Explicit Decimal Serialization?<br/>
        /// System.Decimal is serialized as a string by default by C Sharp MondoDB Driver.<br/>
        /// Due to which decimal.Parse() method does not work as expected, 
        /// and decimal is added as a string in the Database.<br/>
        /// Therefore we are performing explicit decimal serialization.<br/>
        /// <br/>
        /// Serialization in C# is the process of bringing an object into a form that it can be written on stream. <br/>
        /// It's the process of converting the object into a form so that it can be stored on a file, database, or memory;<br/> 
        /// or, it can be transferred across the network.
        /// </summary>
        /// <param name="text">String to be serialized.</param>
        /// <returns>BsonCompatibleDecimal (BsonType.Decimal128) </returns>
        private decimal StringToBsonCompatibleDecimal(string text)
        {
            decimal Decimal128;
            DecimalSerializer decimalSerializer = new DecimalSerializer(BsonType.Decimal128, new RepresentationConverter(allowOverflow: false, allowTruncation: false));
            BsonSerializer.RegisterSerializer(decimalSerializer);
            Decimal128 = decimal.Parse(text);
            return Decimal128;
        }
        */
        #endregion



    } //End of class

} //End of Namespace
